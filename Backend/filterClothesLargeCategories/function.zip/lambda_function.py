import json
import boto3
from boto3.dynamodb.conditions import Key, Attr

# dynamodb 테이블 정보
dynamodb = boto3.resource('dynamodb', region_name='us-east-2')
clothes_table = dynamodb.Table('Clothes')
categories_table = dynamodb.Table('Categories')


def lambda_handler(event, context):
    email = event['pathParameters']['email']
    category = event['pathParameters']['largecategory']
    
    # 큰 카테고리안에 속하는 작은 카테고리들 불러오기
    resp = categories_table.scan(
        FilterExpression=Attr('category_ko').eq(category)
        )
    result = resp['Items']
    
    # 작은 카테고리 리스트
    sub_category_list = []
    for item in result:
        # print(item['category_id'])
        sub_category_list.append(item['category_id'])
    
    print("sub categories: ", sub_category_list)
    
    # clothes table select *
    resp = clothes_table.scan()
    items = resp['Items']
    # print(items)
    
    # clolthes 중에 카테고리가 sub category list에 있는 옷들을 result list에 append
    result_list=[]
    for item in items:
        # print(item, item['category'], type(item['category']))
        if int(item['category']) in sub_category_list:
            result_list.append(item)
            item['clothes_id'] = str(item['clothes_id'])
            item['worn_count'] = str(item['worn_count'])
    
    return {
            "statusCode":200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS, GET",
            },
            "body": json.dumps(result_list, ensure_ascii=False)
        }
